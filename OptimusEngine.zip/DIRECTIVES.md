# Optimus GPU Layer Offload - Project Directives

This document serves as the un-overridable guardrails for the architectural development of the cross-generation GPU offload engine.

## 1. Zero-Python Interconnect (No `torch.distributed`)
- **Directive**: The host-side PCIe handoff logic MUST be written as a bare-metal C++ bridge.
- **Rationale**: Python overhead, the GIL, and `torch.distributed` (NCCL) homogeneity biases are incompatible with extreme-performance asymmetric topologies.
- **Enforcement**: Under no circumstances will we use Python-level `send`/`recv` for intermediate hidden states. All data transit across the PCIe bus must be orchestrated directly by C++ `cudaMemcpyAsync` or P2P equivalents tied to independent CUDA streams.

## 2. Performance & Benchmark First
- **Directive**: Adopt a pure NV layer distribution benchmark-focused approach. Performance is the ultimate priority.
- **Rationale**: We will not compromise on our ideals of maximizing throughput and minimizing latency for the home-lab community. Every architectural decision must be justified by rigorous micro-benchmarks.
- **Enforcement**: I will ensure to write and generate debug info graphics, profiling logs, and performance checks. Everything will be measured.

## 3. Robust Installation & Execution Fallbacks
- **Directive**: All installation, compilation, and execution procedures MUST include robust fallback mechanisms and timeout checks.
- **Enforcement**: If a build or installation process takes longer than expected, I will actively check the process status and logs to detect silent fatal errors, rather than hanging indefinitely.

## 4. Asymmetric Pipeline & Split-Brain Execution
- **Directive**: The engine must compile distinct execution paths for different architectures (e.g., asynchronous TMA/WGMMA for `sm_10x`, synchronous fallback for `sm_75`). Layer distribution must be compute-aware (e.g., 70/30 split).

---
*Note: I will adhere strictly to these directives throughout the development lifecycle.*
